# CledgeFIN Backend
**by BusinessPulse Technologies Limited**

## Setup Instructions

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment variables
```bash
cp .env.example .env
```
Open `.env` and fill in all values.

### 3. Run locally
```bash
npm run dev
```

### 4. Deploy to Railway
- Push this folder to GitHub
- Connect GitHub repo to Railway
- Add all `.env` variables in Railway dashboard
- Railway auto-deploys on every push

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register new subscriber |
| POST | /api/auth/login | Login |
| GET | /api/auth/me | Get profile |
| GET | /api/auth/download-link | Get app download link |
| POST | /api/auth/forgot-password | Request password reset |
| POST | /api/payment/initialize | Start Paystack payment |
| POST | /api/payment/webhook | Paystack webhook (auto) |
| GET | /api/payment/verify/:ref | Verify payment |
| GET | /api/payment/history | Payment history |
| POST | /api/contact | Contact form |
| POST | /api/contact/waitlist | Join waitlist |
| GET | /api/admin/dashboard | Admin dashboard stats |
| GET | /api/admin/subscribers | List all subscribers |
| PATCH | /api/admin/subscribers/:id | Update subscriber |
| POST | /api/admin/subscribers/:id/send-access-code | Send access code |
| POST | /api/admin/subscribers/:id/extend | Extend subscription |
| GET | /api/admin/messages | Contact messages |
| GET | /api/admin/waitlist | Waitlist entries |
| POST | /api/admin/broadcast | Email all subscribers |
| GET | /download/:token | Download app file |
| GET | /health | Server health check |

## Admin Access
Add `x-admin-key: YOUR_ADMIN_SECRET_KEY` header to all admin requests.

## Paystack Webhook
Set webhook URL in Paystack dashboard to:
`https://your-railway-url.up.railway.app/api/payment/webhook`
